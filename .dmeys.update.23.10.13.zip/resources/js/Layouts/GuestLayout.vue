<script setup>

</script>

<template>
    <div class="min-h-screen img-inicio flex flex-col py-4 justify-center items-center">

        <div
            class=" w-full sm:max-w-sm bg-white mt-6 bg-opacity-75 px-6 dark:bg-gray-800 shadow-md overflow-hidden sm:rounded-lg"
        >
            <slot />
        </div>
    </div>
</template>
