<?php

namespace App\Http\Controllers;


use App\Models\Venta;
use Inertia\Inertia;
use Illuminate\Support\Facades\DB;


class CorteCajaController extends Controller
{
  public function __construct()
  {
    //protegiendo el controlador segun el rol
    //$this->middleware(['auth', 'permission:ver-cortecaja'])->only('index');

  }
  public function index()
  {
    $user_id = auth()->user();
    $ventas =  Venta::orderBy('id', 'DESC')->get();
    $l_fechas = Venta::orderBy('id', 'ASC')->get();
    $lista_fechas = [];
    foreach ($l_fechas as $fecha) {
      array_push($lista_fechas, ["name" => $fecha->created_at->format('d/m/Y')]);
    }
    $hoy = date("d/m/Y");

    $nuevo = array_values(array_unique($lista_fechas, SORT_REGULAR));

    $datos = DB::table('pagos as pa')
      ->join('ventas as ve', 've.id', '=', 'pa.venta_id')
      ->join('users as us', 'us.id', '=', 'pa.user_id')
      ->select(DB::raw("pa.id, ve.codigo,us.name AS vendedor,ve.neto,ve.descuento,pa.saldo,ve.total,pa.metodo_pago,pa.metodo_pago_id,pa.monto_efectivo,pa.monto_tarjeta,pa.tipo_pago,pa.forma_entrega,
        DATE_FORMAT(pa.created_at ,'%d/%m/%Y %H:%i:%s') AS fecha"))
      ->orderBy('fecha', 'desc')
      ->where('pa.user_id', '=', $user_id->id)
      //->where('pa.tipo_pago', '=', 'ABONO')
      ->get();

    return Inertia::render('CorteCaja/Index', [
      'cortecaja' => $datos,
      'hoy' => $hoy,
      'lista_fechas' => $nuevo
    ]);
  }
}
